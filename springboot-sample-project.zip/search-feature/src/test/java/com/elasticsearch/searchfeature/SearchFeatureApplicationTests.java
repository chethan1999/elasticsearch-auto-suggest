package com.elasticsearch.searchfeature;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchFeatureApplicationTests {

	@Test
	void contextLoads() {
	}

}
