package com.elasticsearch.searchfeature.service;

import com.elasticsearch.searchfeature.entity.Region;

public interface RegionService {

	public Iterable<Region> insertRegion(Iterable<Region> region);
	
	public Iterable<Region> search();
}
