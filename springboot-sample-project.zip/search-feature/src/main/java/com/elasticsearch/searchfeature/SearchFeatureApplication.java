package com.elasticsearch.searchfeature;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchFeatureApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchFeatureApplication.class, args);
	}

}
