package com.elasticsearch.searchfeature.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.elasticsearch.searchfeature.entity.Region;
import com.elasticsearch.searchfeature.service.ESService;
import com.elasticsearch.searchfeature.service.RegionService;

import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Hit;

@RestController
@RequestMapping("/api/v1")
public class ElasticSearchController {

	@Autowired
	private RegionService regionService;
	
	@Autowired
	private ESService esService;
	
	@GetMapping
	public Iterable<Region> search(){
		return regionService.search();
	}
	
	@PostMapping
	public Iterable<Region> insertRegion(@RequestBody Iterable<Region> region){
		return regionService.insertRegion(region);
	}
	
	@GetMapping("/autosuggest")
	public List<String> autoSuggestProductSearch(@RequestParam String partialRegionName) throws ElasticsearchException, IOException{
		SearchResponse<Region> searchResponse = esService.autoSuggestRegion(partialRegionName);
		List<Hit<Region>> hitList = searchResponse.hits().hits();
		List<Region> regionList = new ArrayList<>();
		
//		hitList.stream().forEach(hit -> regionList.add(hit.source()));
		for(Hit<Region> hit: hitList) {
			regionList.add(hit.source());
		}
		
		List<String> regions = new ArrayList<>();
		for(Region region : regionList) {
			regions.add(region.getName());
		}
//		regionList.stream().forEach(region -> regions.add(region.getName()));
		return regions;
	}
}
