package com.elasticsearch.searchfeature.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elasticsearch.searchfeature.entity.Region;
import com.elasticsearch.searchfeature.repository.RegionRepository;

@Service
public class RegionServiceImpl implements RegionService{

	@Autowired
	private RegionRepository regionRepository;
	
	@Override
	public Iterable<Region> search() {
		System.out.println("Inside service");
		return regionRepository.findAll();
	}

	@Override
	public Iterable<Region> insertRegion(Iterable<Region> region) {
		
		return regionRepository.saveAll(region);
	}

	
}
