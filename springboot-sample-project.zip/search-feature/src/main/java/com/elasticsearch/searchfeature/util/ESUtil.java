package com.elasticsearch.searchfeature.util;

import java.util.function.Supplier;

import co.elastic.clients.elasticsearch._types.query_dsl.MatchQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import lombok.val;

public class ESUtil {

	public static Supplier<Query> createSupplierAutoSuggest(String partialRegionName){
		Supplier<Query> supplier = () -> Query.of(q->q.match(createAutoSuggestMatchQuery(partialRegionName)));
		return supplier;
	}
	public static MatchQuery createAutoSuggestMatchQuery(String partialRegionName) {
		val autoSuggestQuery = new MatchQuery.Builder();
		return autoSuggestQuery.field("name")
				.query(partialRegionName)
				.analyzer("standard")
				.build();
	}
}
