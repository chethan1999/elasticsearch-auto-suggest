package com.elasticsearch.searchfeature.service;

import java.io.IOException;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elasticsearch.searchfeature.entity.Region;
import com.elasticsearch.searchfeature.util.ESUtil;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch.core.SearchResponse;

@Service
public class ESService {

	@Autowired
	private ElasticsearchClient elasticSearchClient;
	
	public SearchResponse<Region> autoSuggestRegion(String partialRegionName) throws ElasticsearchException, IOException{
		
		Supplier<Query> supplier = ESUtil.createSupplierAutoSuggest(partialRegionName);
		SearchResponse<Region> searchResponse = elasticSearchClient.search(s -> s.index("region").query(supplier.get()),Region.class);
		return searchResponse;
	}
}
