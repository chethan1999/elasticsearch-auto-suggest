package com.elasticsearch.searchfeature.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.elasticsearch.searchfeature.entity.Region;

@Repository
public interface RegionRepository extends ElasticsearchRepository<Region, Integer>{

}
