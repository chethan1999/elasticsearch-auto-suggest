package com.elasticsearch.searchfeature.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document(indexName = "region")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Region {

	@Field(type = FieldType.Object, index = false)
    private String _class;
	
	private Integer id;
	
	private String name;
	
	private String wikiDataId;
}
